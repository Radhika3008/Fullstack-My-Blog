// importing React
import React from 'react';

const HomePage = ()=>(
<>
    
         <h1>Hello , welcome to my blog!</h1>
    <p style={{textIndent :'60px'}}>
    Contrary to popular belief, Lorem Ipsum is not simply random text.
     It has roots in a piece of classical 
    Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, 
    a Latin professor at Hampden-Sydney College in Virginia, looked up one o
    </p>
    <p >
    Contrary to popular belief, Lorem Ipsum is not simply random text.
     It has roots in a piece of classical 
    Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, 
    a Latin professor at Hampden-Sydney College in Virginia, looked up one o

    </p>

    </>
   
)
export default HomePage; 